<?php

// Assuming you have already connected to your database
// Replace the database connection details with your own
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$email = $_POST['signin-email']; // You should validate and sanitize user input
$password = $_POST['signin-password'];

if (empty($email) || empty($password)) {
    die("Please enter both email and password.");
}

// Use prepared statements to prevent SQL injection
$sql = "SELECT email, passord FROM amar_dance.users WHERE email = '$email'";
$result = mysqli_query($conn, $sql);

if ($result) {
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $db_email = $row['email'];
        $db_password = $row['passord'];

        // Debugging output
        echo "Entered Password: $password<br>";
        echo "Database Password: $db_password<br>";

        // Compare hashed password using password_verify()
        if ($password == $db_password) {
            setcookie("login_id", $db_email, time() + (86400 * 30), "/");
            echo "Login successful!";
            header("Location: overview.html");
            exit(); // Make sure to exit after header redirect
        } else {
            echo "Password invalid. Please try again.";
        }
    } else {
        echo "No user found with that email.";
    }
} else {
    echo "Error executing the query: " . mysqli_error($conn);
}

// Close the connection
mysqli_close($conn);
?>
