<?php
// Assuming you have already connected to your database
// Replace the database connection details with your own
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if (isset($_POST['description'])) {
    $mydescription = $_post ['review'];
    $email = $_POST['signin-email']; // You should validate and sanitize user input
    $password = $_POST['signin-password'];

    $sql = "INSERT into amar_dance.review (review_id, url, Description) values (null,$myurl, $mydescription)"; 
    $stmt = mysqli_prepare($conn, $query);

    if ($stmt) {
        echo"Thank you for your feedback";
        echo"";
    }else {
        echo"Oop! An error occur and your feedback was not recorded.";
    }
}
$conn->close();
?>
