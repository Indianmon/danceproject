<?php
// Assuming you have already connected to your database
// Replace the database connection details with your own
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['signup-email']) && isset($_POST['signup-password'])) {
   
    $email = $_POST['signup-email']; // You should validate and sanitize user input
    $password = $_POST['signup-password'];

    // Use prepared statements to prevent SQL injection
    $sql = "SELECT FROM amar_dance.users email,passord where email =$email and passord = $password";
    
    $stmt = mysqli_prepare($conn, $sql);

    // Bind parameters to the prepared statement
    mysqli_stmt_bind_param($stmt, "sss",$email, $password);

    // Execute the prepared statement
    $login_sql = mysqli_stmt_execute($stmt);

    if ($login_sql) {
        echo "Account created successfully!";
        header("Location: homepage.html");
    } else {
        echo "Account was not created successfully!";
    }

    // Close the statement
    mysqli_stmt_close($stmt);
}

// Close the connection
mysqli_close($conn);
?>
