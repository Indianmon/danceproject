<?php



        $from = "tamegnom@kean.edu";

        $to = "tamegnom@kean.edu";

        $subject = "Hello Sendmail.";

        $message = "This is an test email to test Sendmail.";

        $headers = [ "From: $from" ];

        mail( $to, $subject, $message, implode( '\r\n', $headers ) ); ?>