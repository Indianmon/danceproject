<?php
// Replace these values with your actual database credentials
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


    // Use prepared statements to prevent SQL injection
    $stmt  = $conn->prepare("INSERT INTO users (user_id, username, email, passord) VALUES (null,?,?,?)");
    
    // Bind parameters to the prepared statement
    //prevent sql injection
    $stmt->bind_param("sss", $name, $email, $password);
    // Execute the prepared statement
    ##$insert_result = mysqli_stmt_execute($stmt);
    $name = $_POST['signup-name'];
    $password = $_POST['signup-password'];
    $email = $_POST['signup-email'];
    if ($stmt->execute()) {
        echo "User added successfully!";
        header("location: overview.html");
    } else {
        echo "Error adding user: " . mysqli_error($conn);
    }

// Close the connection
mysqli_close($conn);
?>
