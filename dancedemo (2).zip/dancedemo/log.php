<?php
// Assuming you have already connected to your database
// Replace the database connection details with your own
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['signin-email']) && isset($_POST['signin-password'])) {
    $email = $_POST['signin-email']; // You should validate and sanitize user input
    $password = $_POST['signin-password'];

    // Use prepared statements to prevent SQL injection
    $sql = "SELECT email, passord FROM amar_dance.users WHERE email = ?";
    $stmt = mysqli_prepare($conn, $sql);

    // Bind the parameter to the prepared statement
    mysqli_stmt_bind_param($stmt, "s", $email);

    // Execute the prepared statement
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        // Bind the result variables
        mysqli_stmt_bind_result($stmt, $db_email, $db_password);

        // Fetch the values
        mysqli_stmt_fetch($stmt);

        if (password_verify($password, $db_password) && $email == $db_email) {
            setcookie("login_id", $db_email, time() + (86400 * 30), "/");
            echo "Login successful!";
            header("Location: home.html");
        } else {
            echo "Password invalid. Please try again.";
        }
        
        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        echo "Error executing the query: " . mysqli_error($conn);
    }
} else {
    echo "Invalid input.";
}

// Close the connection
mysqli_close($conn);
?>
