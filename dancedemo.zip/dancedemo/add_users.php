<?php
// Assuming you have already connected to your database
// Replace the database connection details with your own
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_POST['signup-name']) && isset($_POST['signup-email']) && isset($_POST['signup-password'])) {
    $name = $_POST['signup-name'];
    $email = $_POST['signup-email']; // You should validate and sanitize user input
    $password = $_POST['signup-password'];

    // Use prepared statements to prevent SQL injection
    $sql = "INSERT INTO amar_dance.users(user_id, username, email, passord) VALUES (null, $name,$email, $password)";
    $insert_sql = mysqli_query($conn, $sql);


    if (($insert_sql) === TRUE) {
        echo "Account created successfully!";
        header("Location: overview.html");
    } else {
        echo "Account was not created successfully!";
    }


}

// Close the connection
mysqli_close($conn);
?>
