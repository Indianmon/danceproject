<?php
// Assuming you have already connected to your database
// Replace the database connection details with your own
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());

}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST['password'];
// You should validate and sanitize user input
    // Use prepared statements to prevent SQL injection
    $sql = "SELECT * FROM amar_dance.users where email = $email";
    $result = mysqli_query($conn, $sql);
   
    if ($result){
        echo"query successful";
        if (mysqli_num_rows($result)>0){
            $row = mysqli_fetch_array($result);
            $db_password = $row['passord'];
            if ($password == $db_password ){
                echo"login successful!";
                #header("Location: home.html");
            }else{
                echo"Password invalid. Please try again.";
            }
        }else{
            echo"No such record found in Database for $email.";  
        }
    }else{
        echo "Account was not created successfully!";
    }
}else{
    echo"...";
}
// Close the connection
mysqli_close($conn);
?>
