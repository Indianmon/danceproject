<?php
// Replace these values with your actual database credentials
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);

// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the required POST variables are set
    if (isset($_POST['signup-name'], $_POST['signup-password'], $_POST['signup-email'])) {
        // Use prepared statements to prevent SQL injection
        $query  = "INSERT INTO amar_dance.users (user_id, username, email, passord) VALUES (null,?,?,?)";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            die('Error in prepare statement: ' . $conn->error);
        }

        // Bind parameters to the prepared statement
        // Prevent SQL injection
        $name = $_POST['signup-name'];
        $password = $_POST['signup-password'];
        $email = $_POST['signup-email'];
        $stmt->bind_param("sss", $name, $email, $password);

        // Execute the prepared statement
        $result = $stmt->execute();
        
        if ($result) {
            echo "User added successfully!";
            // Redirect to another page if needed
            // header("location: overview.html");
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "All form fields are required.";
    }
}else{
    echo "....";
}

// Close the connection
mysqli_close($conn);
?>
