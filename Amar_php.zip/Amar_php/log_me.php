<?php
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

$conn = mysqli_connect($servername, $username, $password, $database);

$username = $_POST['signin-email'];  
$password = $_POST['signin-password'];  

//to prevent from mysqli injection  
$username = stripcslashes($username);  
$password = stripcslashes($password);  
$username = mysqli_real_escape_string($conn, $username);  
$password = mysqli_real_escape_string($conn, $password);  

$sql = "SELECT * from users where email = '$username' and passord = '$password'";  
$result = mysqli_query($conn, $sql);  
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
$count = mysqli_num_rows($result);  
    
if($count == 1){  
    echo "<h1><center> Login successful </center></h1>";  
}  
else{  
    echo "<h1> Login failed. Invalid username or password.</h1>";  
}     
?>  