<?php
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if ($conn) {
    echo "Connected successfully!";
} else {
    echo "Connection failed: " . mysqli_connect_error();
}
?>