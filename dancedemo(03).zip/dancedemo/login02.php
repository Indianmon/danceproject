<?php

// Assuming you have already connected to your database
// Replace the database connection details with your own
$servername = "localhost";
$username = "root";
$password = "Ilovejohan@17";
$database = "amar_dance";

$conn = mysqli_connect($servername, $username, $password, $database);

$email = $_POST['signin-email']; // You should validate and sanitize user input
$password = $_POST['signin-password'];



// Check the connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
if ($email = ''){
    die("Please enter email:");
}
    // Use prepared statements to prevent SQL injection
    $sql = "SELECT email, passord FROM amar_dance.users";
    $sql= $sql . "WHERE email = '$email'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            $email = $row['email'];
            $dpassword = $row['passord'];
        if ($password == $dpassword) {
            setcookie("login_id", $db_email, time() + (86400 * 30), "/");
            echo "Login successful!";
            header("Location: home.html");
        } else {
            echo "Password invalid. Please try again.";
        }

    } else {
        echo "Error executing the query: " . mysqli_error($conn);
    }
} else {
    echo "Invalid input.";
}

// Close the connection
mysqli_close($conn);
?>